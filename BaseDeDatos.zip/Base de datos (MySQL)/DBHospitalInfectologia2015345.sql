-- Programador: 
-- Carlos Daniel Jax Tax
-- Fecha de creacion:
-- 07/05/2019

-- DROP DATABASE DBHospitalInfectologia2015345;
CREATE DATABASE DBHospitalInfectologia2015345; 

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'admin';

USE DBHospitalInfectologia2015345; 

-- TABLAS ========================================================================================
CREATE TABLE Cargos(
	codigoCargo int not null auto_increment, 
    nombreCargo varchar(50),
    Primary Key PK_codigoCargo(codigoCargo)
);

CREATE TABLE Areas(
	codigoArea int not null auto_increment, 
    nombreArea varchar(50),
    Primary Key PK_codigoArea(codigoArea)
    
);

CREATE TABLE Horarios(
	codigoHorario int not null auto_increment,
    horarioInicio varchar(10) not null, 
    horarioSalida varchar(10) not null,
    lunes BOOLEAN, 
    martes BOOLEAN,
    miercoles BOOLEAN,
    jueves BOOLEAN,
    viernes BOOLEAN,
    Primary Key PK_codigoHorario(codigoHorario)
    
);


CREATE TABLE Pacientes(
	codigoPaciente int not null auto_increment,
    DPI varchar(50) not null,
    apellidos varchar(50) not null, 
    nombres varchar(50) not null, 
    fechaNacimiento date not null, 
    edad int default 0, 
    direccion varchar(50) not null, 
    ocupacion varchar(50) not null, 
    sexo varchar(50),
    Primary Key PK_codigoPaciente(codigoPaciente)

);


CREATE TABLE Medicos(
	codigoMedico int not null auto_increment, 
    licenciaMedica integer not null, 
    nombres varchar(100) not null,
    apellidos varchar(100) not null,
    horaEntrada varchar(10) not null, 
    horaSalida varchar(10) not null, 
    turnoMaximo int DEFAULT 0, 
    sexo varchar(20),
    Primary Key PK_codigoMedico(codigoMedico)
);

CREATE TABLE contactoUrgencia(
	codigoContactoUrgencia int not null auto_increment, 
    apellidos varchar(50),
    nombres varchar(50),
    numeroContacto varchar(50), 
    codigoPaciente int not null, 
    Primary Key PK_codigoContactoUrgencia(codigoContactoUrgencia), 
    CONSTRAINT FK_contactoUrgencia_Pacientes Foreign Key (codigoPaciente) REFERENCES Pacientes(codigoPaciente)
		on DELETE CASCADE
    
);

CREATE TABLE Especialidades(
	codigoEspecialidad int not null auto_increment, 
    nombreEspecialidad varchar(50) not null, 
    Primary Key PK_codigoEspecialidad(codigoEspecialidad)
    
);

CREATE TABLE Medico_Especialidad(
	codigoMedicoEspecialidad int not null auto_increment, 
    codigoMedico int not null, 
    codigoEspecialidad int not null, 
    codigoHorario int not null, 
    Primary Key PK_codigoMedicoEspecialidad(codigoMedicoEspecialidad),
    CONSTRAINT FK_Medico_Especialidad_Especialidades Foreign Key (codigoEspecialidad) REFERENCES Especialidades(codigoEspecialidad), 
    CONSTRAINT FK_Medico_Especialidad_Horarios Foreign Key (codigoHorario) REFERENCES Horarios(codigoHorario), 
    CONSTRAINT FK_Medico_Especialidad_Medicos Foreign Key (codigoMedico) REFERENCES Medicos(codigoMedico)
		ON DELETE CASCADE
    
);

CREATE TABLE TelefonoMedico(
	codigoTelefonoMedico int not null auto_increment, 
    telefonoPersonal varchar(50) not null, 
    telefonoTrabajo varchar(50), 
    codigoMedico int not null, 
    Primary Key PK_codigoTelefonoMedico(codigoTelefonoMedico), 
    CONSTRAINT FK_TelefonoMedico_Medicos Foreign Key (codigoMedico) REFERENCES Medicos(codigoMedico)
		ON DELETE CASCADE

);

CREATE TABLE ResponsableTurno(
	codigoResponsableTurno int not null auto_increment, 
    nombreResponsable varchar(50), 
    apellidosResponsable varchar(50), 
    telefonoPersonal varchar(50), 
    codigoArea int not null, 
    codigoCargo int not null, 
    Primary Key PK_codigoResponsableTurno(codigoResponsableTurno), 
    CONSTRAINT FK_ResponsableTurno_Areas Foreign Key (codigoArea) REFERENCES Areas(codigoArea),
    CONSTRAINT FK_ResponsableTurno_Cargos Foreign Key (codigoCargo) REFERENCES Cargos(codigoCargo)
		ON DELETE CASCADE
);

CREATE TABLE Turno(
	codigoTurno int not null auto_increment, 
    fechaTurno date not null, 
    fechaCita date not null, 
    valorCita decimal (10,2), 
    codigoMedicoEspecialidad int not null,
    codigoTurnoResponsable int not null, 
    codigoPaciente int not null, 
    Primary Key PK_codigoTurno(codigoTurno), 
    CONSTRAINT FK_Turno_ResponsableTurno Foreign Key (codigoTurnoResponsable) REFERENCES ResponsableTurno(codigoResponsableTurno), 
    CONSTRAINT FK_Turno_Medico_Especialidad Foreign Key (codigoMedicoEspecialidad) REFERENCES Medico_Especialidad(codigoMedicoEspecialidad), 
    CONSTRAINT FK_Turno_Pacientes Foreign Key (codigoPaciente) REFERENCES Pacientes(codigoPaciente)
		ON DELETE CASCADE
);

-- -----------------PROCEDIMIENTO DE CARGOS ===============================================================================
-- -----------------------------------------------------------------------------------------
Delimiter $$
Create procedure sp_AgregarCargos(IN cargo varchar(45))
BEGIN
	Insert into Cargos(nombreCargo)
		values(cargo); 
End$$
Delimiter ;

Delimiter $$
Create procedure sp_ListarCargos()
BEGIN
	select 
		Cargos.codigoCargo, 
		Cargos.nombreCargo
		From Cargos;
End$$
Delimiter ; 

Delimiter $$
Create procedure sp_BuscarCargo(IN codigo int)
BEGIN
	Select 
		Cargos.codigoCargo, 
		Cargos.nombreCargo
		From Cargos 
			Where codigoCargo = codigo; 
End$$
Delimiter ; 

Delimiter $$
	Create procedure sp_EditarCargo(IN codigo int, IN nuevo varchar(45))
    BEGIN
		Update Cargos set nombreCargo = nuevo
			Where codigoCargo = codigo; 
	End$$
Delimiter ; 

Delimiter $$
	Create procedure sp_EliminarCargo(IN codigo int)
    BEGIN
		Delete from Cargos
			Where codigoCargo = codigo; 
	End$$
Delimiter ;

-- call sp_AgregarCargos('Doctor');
-- call sp_ListarCargos();
-- call sp_EliminarCargo(1);
-- -----------------PROCEDIMIENTO DE AREAS =============================================================================
-- -------------------------------------------------------------------------------------------
Delimiter $$
	Create procedure sp_AgregarAreas(IN area varchar(45))
    BEGIN
		Insert into Areas(nombreArea)
			values(area); 
	End$$
Delimiter ;

Delimiter $$
	Create procedure sp_ListarAreas()
    BEGIN
		select 
			Areas.codigoArea, 
            Areas.nombreArea
            From Areas;
	End$$
Delimiter ; 

Delimiter $$
	Create procedure sp_BuscarAreas(IN codigo int)
    BEGIN
		Select 
			Areas.codigoArea, 
            Areas.nombreArea
            From Areas 
				Where codigoArea = codigo; 
    End$$
Delimiter ; 

Delimiter $$
	Create procedure sp_EditarAreas(IN codigo int, IN nombre varchar(45))
    BEGIN
		Update Areas set 
        nombreArea = nombre
			Where codigoArea = codigo; 
	End$$
Delimiter ; 

Delimiter $$
	Create procedure sp_EliminarAreas(IN codigo int)
    BEGIN
		Delete from Areas
			Where codigoArea = codigo; 
	End$$
Delimiter ; 
-- DROP PROCEDURE sp_EditarAreas;
-- call sp_AgregarAreas('Medico');
-- call sp_ListarAreas();
-- call sp_EliminarAreas(1);
-- call sp_EditarAreas('Veterinario', 1);

-- -----------------PROCEDIMIENTO DE PACIENTES===================================================================================
-- ---------------------------------------------------------------------------------------------------
Delimiter $$
Create procedure sp_AgregarPacientes(IN DPI varchar(45), in apellidos varchar (50), in nombres varchar(50),
	in fecha date, in direccion varchar(50), in ocupacion varchar (50), in sexo varchar(50))
    BEGIN
	Insert into Pacientes(DPI, apellidos, nombres, fechaNacimiento, direccion, ocupacion, sexo)
		values(DPI, apellidos, nombres, fecha, direccion, ocupacion, sexo); 
End$$
Delimiter ;
-- DROP PROCEDURE sp_EliminarPacientes;
Delimiter $$
Create procedure sp_ListarPacientes()
BEGIN
	select 
		Pacientes.codigoPaciente, 
		Pacientes.DPI,
        Pacientes.apellidos,
        Pacientes.nombres,
        Pacientes.fechaNacimiento,
        Pacientes.edad,
		Pacientes.direccion,
        Pacientes.ocupacion,
        Pacientes.sexo
        FROM Pacientes;
End $$
Delimiter ; 

DELIMITER $$
CREATE PROCEDURE sp_BuscarPacientes(in codigo int) 
    SELECT  
		Pacientes.codigoPaciente, 
		Pacientes.DPI,
        Pacientes.apellidos,
        Pacientes.nombres,
        Pacientes.fechaNacimiento,
        Pacientes.edad,
		Pacientes.direccion,
        Pacientes.ocupacion,
        Pacientes.sexo
        FROM Pacientes;
			WHERE codigoPaciente = codigo;
END $$
DELIMITER ;
																																
DELIMITER $$
Create procedure sp_EditarPacientes(IN codigo int, IN DPI varchar(45), in apellidos varchar (50), in nombres varchar(50),
	in fecha date, in direccion varchar(50), in ocupacion varchar (50), in sexo varchar(50))
    BEGIN
	Update Pacientes set 
		DPI = DPI,
        apellidos = apellidos,
        nombres = nombres,
        fechaNacimiento = fecha,
		direccion = direccion,
        ocupacion = ocupacion,
        sexo = sexo
		Where codigoPaciente = codigo; 
End$$
Delimiter ; 

Delimiter $$
	Create procedure sp_EliminarPacientes(IN codigo int)
    BEGIN
		Delete from Pacientes
			Where codigoPaciente = codigo; 
	End$$
Delimiter ;

-- call sp_ListarPacientes();
-- call sp_AgregarPacientes('8230986', 'Jax Tax', 'Carlos Daniel', '2001-02-02', '23 calle 2-83 zona 3', 'Comerciante', 'Masculino');
-- call sp_EditarPacientes(5, '8230986', 'Jax Tax', 'Carlos Daniel', '2001-02-02', '23 calle 2-83 zona 3', 'Comerciante', 'Masculino');

-- call sp_EliminarPacientes(5);
-- ------------------ PROCEDIMIENTOS DE MEDICOS =======================================================================================
-- DROP PROCEDURE sp_AgregarMedicos; 
DELIMITER $$
CREATE PROCEDURE sp_AgregarMedicos (in licencia integer, in nombres varchar (100), in apellidos varchar(100), in horaE varchar(10), 
										in horaS varchar(10), in sexo varchar(20))
	BEGIN
	INSERT INTO Medicos(licenciaMedica, nombres, apellidos, horaEntrada, horaSalida, sexo)
		values (licencia, nombres, apellidos, horaE, horaS, sexo);
END $$
DELIMITER ;

-- call sp_AgregarMedicos (125555, 'Carlos Stive', 'Salazar Valiente', '08:20:23', '17:45:14', 'masculino');
-- call sp_AgregarMedicos (225500, 'Jose Hernandez', 'Chajon Perez', '07:23:20', '18:30:45', 'masculino');
-- call sp_AgregarMedicos (123456, 'Cristian Jimenez', 'Pirir Perez', '06:45:21', '20:45:11', 'masculino');

-- SELECT * FROM Medicos;

DELIMITER $$
CREATE PROCEDURE sp_listarMedicos ()
BEGIN
	SELECT 
		Medicos.codigoMedico,
        Medicos.licenciaMedica,
        Medicos.nombres,
        Medicos.apellidos,
        Medicos.horaEntrada,
        Medicos.horaSalida,
        Medicos.turnoMaximo,
        Medicos.sexo
        FROM Medicos;
END $$
DELIMITER ;
-- CALL sp_listarMedicos();
-- DROP PROCEDURE sp_BuscarMedicos;
DELIMITER $$
CREATE PROCEDURE sp_BuscarMedicos(in codigo int)
BEGIN
	SELECT 
		Medicos.codigoMedico,
        Medicos.licenciaMedica,
        Medicos.nombres,
        Medicos.apellidos,
        Medicos.horaEntrada,
        Medicos.horaSalida,
        Medicos.turnoMaximo,
        Medicos.sexo
        FROM Medicos
			WHERE codigoMedico = codigo;
END $$
DELIMITER ;
-- call sp_BuscarMedicos (1);

DELIMITER $$
CREATE PROCEDURE sp_EditarMedicos(IN codigo int, in licencia integer, in nombres varchar (50), in apellidos varchar (50), 
	in horaE varchar(10), in horaS varchar(10), in sexo varchar (50))
    BEGIN
	Update Medicos set 
		licenciaMedica = licencia,
		nombres = nombres,
        apellidos = apellidos,
        horaEntrada = horaE,
        horaSalida = horaS,
        sexo = sexo
		Where codigoMedico = codigo; 
End$$
Delimiter ; 
-- call sp_EditarMedicos (4, 256564, 'Karla Emanuel', 'Perez Perez', '8:00:00', '20:00:45', 'Femenino');

Delimiter $$
	CREATE PROCEDURE sp_EliminarMedicos(IN codigo int)
    BEGIN
		Delete from Medicos
			Where codigoMedico = codigo; 
	End$$
Delimiter ;
-- call sp_EliminarMedicos(1);

-- ----------- PROCEDIMIENTOS HORARIOS ===========================================================================================
-- ------------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE sp_AgregarHorarios (in horaI varchar(10), in horaS varchar(10), in lunes tinyint, in martes tinyint, 
	in miercoles tinyint, jueves tinyint, viernes tinyint)
    BEGIN
	INSERT INTO Horarios(horarioInicio, horarioSalida, lunes, martes, miercoles, jueves, viernes)
		values (horaI, horaS, lunes, martes, miercoles, jueves, viernes);
END $$
DELIMITER ;

-- SELECT * FROM Horarios;

DELIMITER $$
CREATE PROCEDURE sp_listarHorarios ()
BEGIN
	SELECT 
		Horarios.codigoHorario,
        Horarios.horarioInicio,
        Horarios.horarioSalida,
        Horarios.lunes,
        Horarios.martes,
        Horarios.miercoles,
        Horarios.jueves,
        Horarios.viernes
        FROM Horarios;
END $$
DELIMITER ;
-- CALL sp_listarHorarios();

DELIMITER $$
CREATE PROCEDURE sp_BuscarHorarios(in codigo int)
BEGIN
	SELECT 
		Horarios.codigoHorario,
        Horarios.horarioInicio,
        Horarios.horarioSalida,
        Horarios.lunes,
        Horarios.martes,
        Horarios.miercoles,
        Horarios.jueves,
        Horarios.viernes
        FROM Horarios
			WHERE codigoHorario = codigo;
END $$
DELIMITER ;
-- CALL sp_BuscarMedicos (3);

DELIMITER $$
CREATE PROCEDURE sp_EditarHorarios (in codigo int, in horaI varchar(10), in horaS varchar(10), in lunes tinyint, in martes tinyint, 
	in miercoles tinyint, jueves tinyint, viernes tinyint)
    BEGIN
	Update Horarios set 
        horarioInicio = horaI,
        horarioSalida = horaS,
        lunes = lunes,
        martes = martes,
        miercoles = miercoles,
        jueves = jueves,
        viernes = viernes
		Where codigoHorario = codigo; 
End$$
Delimiter ; 
-- DROP PROCEDURE sp_EditarHorarios;
Delimiter $$
	CREATE PROCEDURE sp_EliminarHorarios(IN codigo int)
    BEGIN
		Delete from Horarios
			Where codigoHorario = codigo; 
	End$$
Delimiter ;

-- ------------------ PROCEDIMIENTOS CONTACTOURGENCIA ==========================================================================
-- ------------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE sp_AgregarContacto (in apellidos varchar(50), in nombres varchar(50), in numero varchar(50), in codigo int)
BEGIN
	INSERT INTO contactoUrgencia(apellidos, nombres, numeroContacto, codigoPaciente)
		values (apellidos, nombres, numero, codigo);
END $$
DELIMITER ;

-- SELECT * FROM contactoUrgencia;
-- DROP PROCEDURE sp_BuscarContactos;
DELIMITER $$
CREATE PROCEDURE sp_listarContacto ()
BEGIN
	SELECT 
		contactoUrgencia.codigoContactoUrgencia,
        contactoUrgencia.apellidos,
        contactoUrgencia.nombres,
        contactoUrgencia.numeroContacto,
        contactoUrgencia.codigoPaciente
        FROM contactoUrgencia;
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE sp_BuscarContactos(in codigo int)
BEGIN
	SELECT 
		contactoUrgencia.codigoContactoUrgencia,
        contactoUrgencia.apellidos,
        contactoUrgencia.nombres,
        contactoUrgencia.numeroContacto,
        contactoUrgencia.codigoPaciente
        FROM contactoUrgencia
			WHERE codigoContactoUrgencia = codigo;
END $$
DELIMITER ;
-- CALL sp_BuscarContactos (6);

DELIMITER $$
CREATE PROCEDURE sp_EditarContacto (in codigoINT int, in apellidos varchar(50), in nombres varchar(50), in numero varchar(50), in codigo int)
BEGIN
	Update contactoUrgencia set 
        apellidos = apellidos,
        nombres = nombres,
        numeroContacto = numero,
		codigoPaciente = codigo
		Where codigoContactoUrgencia = codigoINT; 
End$$
Delimiter ; 

Delimiter $$
CREATE PROCEDURE sp_EliminarContactos(IN codigo int)
BEGIN
		Delete from contactoUrgencia
			Where codigoContactoUrgencia = codigo; 
	End$$
Delimiter ;

-- call sp_AgregarContacto('Jax Tax', 'Carlos Daniel', '45556501', 1);
-- call sp_listarContacto();
-- call sp_EliminarContactos(1);

-- -------------------- PROCEDIMIENTOS ESPECIALIDADES ==========================================================================
-- ------------------------------------------------------------------------------------------------ 
DELIMITER $$
CREATE PROCEDURE sp_AgregarEspecialidades (in nombre varchar (50))
BEGIN
	INSERT INTO Especialidades(nombreEspecialidad)
		values (nombre);
END $$
DELIMITER ;

-- SELECT * FROM Especialidades;

DELIMITER $$
CREATE PROCEDURE sp_listarEspecialidades ()
BEGIN
	SELECT 
		Especialidades.codigoEspecialidad,
        Especialidades.nombreEspecialidad
        FROM Especialidades;
END $$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE sp_BuscarEspecialidades(in codigo int)
BEGIN
	SELECT 
		Especialidades.codigoEspecialidad,
        Especialidades.nombreEspecialidad
        FROM Especialidades
			WHERE codigoEspecialidad = codigo;
END $$
DELIMITER ;
-- CALL sp_BuscarEspecialidades (3);

DELIMITER $$
CREATE PROCEDURE sp_EditarEspecialidades (in codigo int, in nombre varchar (50))
BEGIN
	Update Especialidades set 
        nombreEspecialidad = nombre 
		Where codigoEspecialidad = codigo; 
End$$
Delimiter ; 

Delimiter $$
	CREATE PROCEDURE sp_EliminarEspecialidades(IN codigo int)
    BEGIN
		Delete from Especialidades
			Where codigoEspecialidad = codigo; 
	End$$
Delimiter ;

-- call sp_AgregarEspecialidades('Dentista');
-- call sp_listarEspecialidades();
-- call sp_EliminarEspecialidades();
-- call sp_EditarEspecialidades(2, 'Doctor');


-- ---------------------- PROCEDIMIENTOS MEDICO_ESPECIALIDAD ===================================================================
-- -------------------------------------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE sp_AgregarMedico_Especialidad (in medico int, in especial int, in hora int)
BEGIN
	INSERT INTO Medico_Especialidad(codigoMedico, codigoEspecialidad, codigoHorario)
		values (medico, especial, hora);
END $$
DELIMITER ;

-- call sp_AgregarMedico_Especialidad(1, 1, 1);
-- SELECT * FROM Medico_Especialidad;

DELIMITER $$
CREATE PROCEDURE sp_listarMedico_Especialidad ()
BEGIN
	SELECT 
		Medico_Especialidad.codigoMedicoEspecialidad,
        Medico_Especialidad.codigoMedico,
        Medico_Especialidad.codigoEspecialidad,
        Medico_Especialidad.codigoHorario
        FROM Medico_Especialidad;
END $$
DELIMITER ;
-- CALL sp_listarMedico_Especialidad();

DELIMITER $$
CREATE PROCEDURE sp_BuscarMedico_Especialidad(in codigo int)
BEGIN
	SELECT 
		Medico_Especialidad.codigoMedicoEspecialidad,
		Medico_Especialidad.codigoMedico,
        Medico_Especialidad.codigoEspecialidad,
        Medico_Especialidad.codigoHorario
        FROM Medico_Especialidad
			WHERE codigoEspecialidad = codigo;
END $$
DELIMITER ;

-- CALL sp_BuscarMedico_Especialidad(3);

DELIMITER $$
CREATE PROCEDURE sp_EditarMedico_Especialidad (in codigo int, in codigoM int, in codigoE int, in codigoH int)
BEGIN
	Update Medico_Especialidad set 
        codigoMedico = codigoM,
        codigoEspecialidad = codigoE,
        codigoHorario = codigoH
		Where codigoMedicoEspecialidad = codigo; 
End$$
Delimiter ; 


Delimiter $$
	CREATE PROCEDURE sp_EliminarMedico_Especialidad(IN codigo int)
    BEGIN
		Delete from Medico_Especialidad
			Where codigoEspecialidad = codigo; 
	End$$
Delimiter ;

-- -------------- PROCEDIMIENTOS TELEFONOMEDICO ==================================================================================
-- -------------------------------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE sp_AgregarTelefonoMedico(in personal varchar (50), in trabajo varchar (50), in medico int)
BEGIN
	INSERT INTO TelefonoMedico(telefonoPersonal, telefonoTrabajo, codigoMedico)
		values (personal, trabajo, medico);
END $$
DELIMITER ;

-- SELECT * FROM TelefonoMedico;

DELIMITER $$
CREATE PROCEDURE sp_listarTelefonoMedico()
BEGIN
	SELECT 
		TelefonoMedico.codigoTelefonoMedico,
        TelefonoMedico.telefonoPersonal,
        TelefonoMedico.telefonoTrabajo,
        TelefonoMedico.codigoMedico
        FROM TelefonoMedico;
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE sp_BuscarTelefonoMedico(in codigo int)
BEGIN
	SELECT 
		TelefonoMedico.codigoTelefonoMedico,
        TelefonoMedico.telefonoPersonal,
        TelefonoMedico.telefonoTrabajo,
        TelefonoMedico.codigoMedico
        FROM TelefonoMedico
			WHERE codigoTelefonoMedico = codigo;
END $$
DELIMITER ;
-- CALL sp_BuscarTelefonoMedico(3);

DELIMITER $$
CREATE PROCEDURE sp_EditarTelefonoMedico(in codigo int, in personal varchar (50), in trabajo varchar (50), in medico int)
BEGIN
	Update TelefonoMedico set 
        telefonoPersonal = personal,
        telefonoTrabajo = trabajo,
        codigoMedico = medico
		Where codigoTelefonoMedico = codigo; 
End$$
Delimiter ; 

Delimiter $$
CREATE PROCEDURE sp_EliminarTelefonoMedico(IN codigo int)
    BEGIN
		Delete from TelefonoMedico
			Where codigoTelefonoMedico = codigo; 
	End$$
Delimiter ;
-- SELECT * FROM TelefonoMedico;
-- call sp_AgregarTelefonoMedico('56254789', '25874123', 1);
-- call sp_listarTelefonoMedico();
-- call sp_EliminarTelefonoMedico(4);
-- call sp_EditarTelefonoMedico(10,'000000', '000000', 1);


-- ------------------- PROCEDIMIENTOS RESPONSABLETURNO ===============================================================
-- -------------------------------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE sp_AgregarResponsableTurno(in nombre varchar (50), in apellidos varchar (50), in telefonoP varchar(50),
	in codigoA int, in codigoC int)
    BEGIN
	INSERT INTO ResponsableTurno(nombreResponsable, apellidosResponsable, telefonoPersonal, codigoArea, codigoCargo)
		values (nombre, apellidos, telefonoP, codigoA, codigoC);
END $$
DELIMITER ;

-- SELECT * FROM ResponsableTurno;

DELIMITER $$
CREATE PROCEDURE sp_listarResponsableTurno()
BEGIN
	SELECT 
		ResponsableTurno.codigoResponsableTurno,
        ResponsableTurno.nombreResponsable,
        ResponsableTurno.apellidosResponsable,
        ResponsableTurno.telefonoPersonal,
        ResponsableTurno.codigoArea,
        ResponsableTurno.codigoCargo
        FROM ResponsableTurno;
END $$
DELIMITER ;
-- CALL sp_listarResponsableTurno();

DELIMITER $$
CREATE PROCEDURE sp_BuscarResponsableTurno(in codigo int)
BEGIN
	SELECT 
		ResponsableTurno.codigoResponsableTurno,
        ResponsableTurno.nombreResponsable,
        ResponsableTurno.apellidosResponsable,
        ResponsableTurno.telefonoPersonal,
        ResponsableTurno.codigoArea,
        ResponsableTurno.codigoCargo
        FROM ResponsableTurno
			WHERE codigoResponsableTurno = codigo;
END $$
DELIMITER ;
-- CALL sp_BuscarResponsableTurno(1);
-- DROP PROCEDURE sp_BuscarResponsableTurno;
DELIMITER $$
CREATE PROCEDURE sp_EditarResponsableTurno(in codigo int, in nombre varchar (50), in apellidos varchar (50), in telefonoP varchar(50),
	in codigoA int, in codigoC int)
    BEGIN
	Update ResponsableTurno set 
        nombreResponsable = nombre, 
        apellidosResponsable = apellidos,
        telefonoPersonal = telefonoP,
        codigoArea = codigoA,
        codigoCargo = codigoC
		Where codigoResponsableTurno = codigo; 
End$$
Delimiter ; 

Delimiter $$
	CREATE PROCEDURE sp_EliminarResponsableTurno(IN codigo int)
    BEGIN
		Delete from ResponsableTurno
			Where codigoResponsableTurno = codigo; 
	End$$
Delimiter ;

-- -------------------PROCEDIMIENTOS TURNO ============================================================================================
-- ------------------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE sp_AgregarTurno(in fechaT date, in fechaC date, in valorC int, in codigoME int, in codigoTR int, in codigoP int)
BEGIN
	INSERT INTO Turno(fechaTurno, fechaCita, valorCita, codigoMedicoEspecialidad, codigoTurnoResponsable, codigoPaciente)
		values (fechaT, fechaC, valorC, codigoME, codigoTR, codigoP);
END $$
DELIMITER ;
-- Drop Procedure sp_AgregarTurno;
-- call sp_AgregarTurno('2001-05-05', '2001-05-05', 45, 2, 1, 1);
-- SELECT * FROM Turno;

DELIMITER $$
CREATE PROCEDURE sp_listarTurno()
BEGIN
	SELECT 
		Turno.codigoTurno,
        Turno.fechaTurno,
        Turno.fechaCita,
        Turno.valorCita,
        Turno.codigoMedicoEspecialidad,
        Turno.codigoTurnoResponsable,
        Turno.codigoPaciente
        FROM Turno;
END $$
DELIMITER ;
-- CALL sp_listarTurno();

DELIMITER $$
CREATE PROCEDURE sp_BuscarTurno(in codigo int)
BEGIN
	SELECT 
		Turno.codigoTurno,
        Turno.fechaTurno,
        Turno.fechaCita,
        Turno.valorCita,
        Turno.codigoMedicoEspecialidad,
        Turno.codigoTurnoResponsable,
        Turno.codigoPaciente
        FROM Turno
			WHERE codigoTurno = codigo;
END $$
DELIMITER ;
-- CALL sp_BuscarTurno(1);

DELIMITER $$
CREATE PROCEDURE sp_EditarTurno(in codigo int, in fechaT date, in fechaC int, in valorC int, in codigoME int, in codigoTR int, in codigoP int)
BEGIN
	Update ResponsableTurno set 
        fechaTurno = fechaT,
        fechaCita = fechaC,
        valorCita = valorC,
        codigoMedicoEspecialidad = codigoME,
        codigoTurnoResponsable = codigoTR,
        codigoPaciente = codigoP
		Where codigoTurno = codigo; 
End$$
Delimiter ; 

Delimiter $$
	CREATE PROCEDURE sp_EliminarTurno(IN codigo int)
    BEGIN
		Delete from Turno
			Where codigoTurno = codigo; 
	End$$
Delimiter ;


