Use DBHospitalInfectologia2015345;

Create table ControlCitas(
	codigoControlCitas int auto_increment not null,
    fecha Date not null,
    horaInicio varchar (45) not null,
    horaFin varchar(45) not null,
    codigoMedico int not null,
    codigoPaciente int not null,
    primary key PK_codigoControlCitas(codigoControlCitas),
    constraint FK_ControlCitas_Medicos foreign key (codigoMedico) references Medicos (codigoMedico),
    constraint FK_ControlCitas_Pacientes foreign key (codigoPaciente) references Pacientes (codigoPaciente)
    on delete cascade
);

Create table Recetas(
	codigoReceta int auto_increment not null,
    descripcionReceta varchar (45),
    codigoControlCita int not null,
    primary key PK_codigoReceta(codigoReceta),
    constraint FK_Recetas_ControlCitas foreign key (codigoControlCita) references ControlCitas (codigoControlCitas) 
    on delete cascade
);



--  PROCEDIMIENTOS ALMACENADOS======================================================
-- ===============================================================
-- CONSULTACITAS========================================================


Delimiter $$
	create procedure sp_AgregarControlCitas (IN fecha date, IN horaInicio varchar (45), IN horaFin varchar (45), IN codigoMedico int, IN codigoPaciente int)
		Begin
			insert into ControlCitas (fecha, horaInicio, horaFin, codigoMedico, codigoPaciente)
				values (fecha, horaInicio, horaFin, codigoMedico, codigoPaciente);
		end$$
Delimiter ;


Delimiter $$
	create procedure sp_EliminarControlCitas (IN Codigo int)
		Begin
			delete from ControlCitas where codigoControlCitas = Codigo;
        End$$
Delimiter ;


Delimiter $$
	create procedure sp_EditarControlCitas (IN codigo int, IN fechas date, IN horaI varchar(45), IN horaF varchar(45))
		Begin
			Update ControlCitas 
            set
            fecha = fechas,
            horaInicio = horaI,
            horaFin = horaF
            where
            codigoControlCitas = codigo;
        End$$
Delimiter ; 
-- drop procedure sp_EliminarControlCitas;

Delimiter $$
create procedure sp_ListarControlCitas ()
	Begin
        select codigoControlCitas, fecha, horaInicio, horaFin, codigoMedico, codigoPaciente from ControlCitas;
        End$$
Delimiter ;

Delimiter $$
	Create procedure sp_BuscarControlCitas(IN codigo int)
    BEGIN
		Select 
			ControlCitas.codigoControlCitas, 
            ControlCitas.fecha,
            ControlCitas.horaInicio,
            ControlCitas.horaFin,
            ControlCitas.codigoMedico,
            ControlCitas.codigoPaciente
            From ControlCitas 
				Where codigoControlCitas = codigo; 
    End$$
Delimiter ; 

-- RECETAS ==========================================================================
-- ==========================================================================

Delimiter $$
	create procedure sp_AgregarRecetas (IN descripcionReceta varchar (45), IN codigoControlCita int)
		Begin
			insert into Recetas (descripcionReceta, codigoControlCita)
				values (descripcionReceta, codigoControlCita);
		end$$
Delimiter ;


Delimiter $$
	create procedure sp_EliminarRecetas (IN Codigo int)
		Begin
			delete from Recetas where ControlCitas = Codigo;
        End$$
Delimiter ;

Delimiter $$
	create procedure sp_EditarRecetas (IN codigo int, IN descripcion varchar(45))
		Begin
			Update Recetas 
            set
            descripcionReceta = descripcion
            
            where
            codigoReceta = codigo;
        End$$
Delimiter ; 

Delimiter $$
	create procedure sp_ListarRecetas ()
		Begin
        select codigoReceta, descripcionReceta, codigoControlCita from Recetas;
        End$$
Delimiter ;

Delimiter $$
	Create procedure sp_BuscarRecetas(IN codigo int)
    BEGIN
		Select 
			Recetas.codigoReceta, 
            Recetas.descripcionReceta,
            Recetas.codigoControlCita
            From Recetas 
				Where codigoReceta = codigo; 
    End$$
Delimiter ; 

-- ------------
-- DROP PROCEDURE sp_EditarRecetas;
call sp_AgregarControlCitas('2001-02-02', '07:00:00', '20:00:00', 1,1);
call sp_ListarControlCitas();
call sp_BuscarControlCitas(1);
call sp_EditarControlCitas(1, '2005-02-10', '07:00:00', '20:00:00', 1,1);
call sp_EliminarControlCitas(2);

-- -----------------------
call sp_AgregarRecetas('Doctor', 1);
call sp_EliminarRecetas(1);
call sp_EditarRecetas(1, 'Paciente', 1);
call sp_ListarRecetas();
call sp_BuscarRecetas(1);

