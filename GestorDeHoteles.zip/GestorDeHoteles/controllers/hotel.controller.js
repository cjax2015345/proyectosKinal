'use strict'

var Hotel = require('../models/hotel.model');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../services/jwt');

function hotelLogin(req, res){
    var params = req.body;
    if(params.name || params.address){
        if(params.password){
            Hotel.findOne({$or:[{name: params.name}, {hotelNumber: params.hotelNumber}]}, (err, check)=>{
                if(err){
                    res.status(500).send({message: 'Error en el servidor'});
                }else if(check){
                    bcrypt.compare(params.password, check.password, (err, passwordOk)=>{
                        if(err){
                            res.status(500).send({message: 'Las contraseñas no son iguales'});
                        }else if(passwordOk){
                            if(params.gettoken = true){
                                res.send({token: jwt.createTokenHotel(check)});
                            }else{
                                res.send({message: 'Bienvenida ', hotel:check});
                            }
                        }else{
                            res.send({message:'Contraseña invalidad'});
                        }
                    });
                }else{
                    res.status(404).send({message: 'Ingrese los datos solicitados'})
                }
            })
        }else{
            res.status(404).send({message: 'Ingrese una contraseña valida'});
        }
    }else{
        res.status(404).send({message: 'Ingrese el nombre o la direccion del hotel'});
    }
};


function saveHotel (req, res){
    var params = req.body;
    var hotel = new Hotel();

    if(params.name && params.address && params.stars){
        Hotel.findOne({$or:[{name: params.name}, {address: params.address}]}, (err, hotelExist)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor'});
            }else if(hotelExist){
                res.send({message: 'El hotel fue registrado con anterioridad'});
            }else{
                hotel.name = params.name;
                hotel.phone = params.phone;
                hotel.stars = params.stars;
                hotel.price = params.price;
                hotel.role = params.role;
                hotel.hotelNumber = Math.round(Math.random()*999999999999999999);
                hotel.password = params.password;
                hotel.fechaDeAtencionI = params.fechaDeAtencionI;
                hotel.fechaDeAtencionF = params.fechaDeAtencionF;

                bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                    if(err){
                        res.status(500).send({message: 'Error al encriptar'});
                    }else if(passwordHash){
                        hotel.password = passwordHash;

                        hotel.save((err, hotelSave)=>{
                            if(err){
                                res.status(500).send({message: err});
                            }else if(hotelSave){
                                res.send({message: 'El hotel '+ params.name + 'se a guardado con exito'});
                            }else{
                                res.status(418).send({message: 'Error al guardar los datos'});
                            }
                        })
                    }else{
                        res.send({message: 'Error inesperado'});
                    }
                })
            }
        })
    }else{
        res.status(404).send({message: 'Ingrese los datos solicitados'});
    };
};


function updateHotel (req, res){
    var hotelId = req.params.id;
    var update = req.body;

    Hotel.findByIdAndUpdate(hotelId, update, {new:true}, (err, hotelUpdate)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(hotelUpdate){
            res.send({message: hotelUpdate});
        }else{
            res.status(404).send({message: 'No se han actualizado los datos del hotel'});
        }
    });
};


function deleteHotel (req, res){
    var hotelId = req.params.id;

    Hotel.findByIdAndDelete(hotelId, (err, hotelDelete)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(hotelDelete){
            res.send({message: 'Hotel Eliminado'});
        }else{
            res.status(404).send({message: 'No se ha eliminado de la Base de Datos'});
        }
    });
};

function listHotel (req, res){
    Hotel.find({}, (err, hotelList)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(hotelList){
            res.send({hoteles: hotelList});
        }else{
            res.status(404).send({message:'No hay datos en la Base de Datos'});
        }
    })
}

module.exports = {
    hotelLogin,
    saveHotel,
    updateHotel,
    deleteHotel,
    listHotel,
}