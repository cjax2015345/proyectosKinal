'use strict'

var User = require('../models/user.model');
var Hotel = require('../models/hotel.model');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../services/jwt');

function loginUser(req, res){
    var params = req.body

    if(params.name || params.email){
        if(params.password){
            User.findOne({$or:[{name: params.name}, {email: params.email}]}, (err, check)=>{
                if(err){
                    res.status(500).send({message: 'Error en el servidor'});
                }else if(check){
                    bcrypt.compare(params.password, check.password, (err, passwordOk)=>{
                        if(err){
                            res.status(500).send({message: 'Error al desencriptar la contraseña'});
                        }else if(passwordOk){
                            if(params.gettoken = true){
                                res.send({token: jwt.createToken(check)});
                            }else{
                                res.send({message: 'Bienvenido de nuevo ', admin: check});
                            }
                        }else{
                           res.status(500).send({message: 'Contraseña incorrecta'}); 
                        }
                    });
                }else{
                    res.status(200).send({message: 'Ingrese los datos solicitados'})
                }
            });
        }else{
            res.status(404).send({message: 'Contraseña incorrecta intentelo de nuevo'});
        }
    }else{
        res.status(404).send({message: 'Ingrese su nombre o email'})
    }
};


function saveUser (req, res){
    var params = req.body;
    var user = new User();

    if(params.name && params.email && params.phone){
        User.findOne({$or:[{name: params.name}, {username: params.username}]}, (err, userReOk)=>{
            if(err){
                res.status(500).send({message: 'Error en el servidor'});
            }else if(userReOk){
                res.send({message: 'Nombre o Usuario ya fueron registrados con anterioridad'});
            }else{
                user.name = params.name;
                user.lastname = params.lastname;
                user.username = params.username;
                user.email = params.email;
                user.phone = params.phone;
                user.role = params.role;
                user.password = params.password;

                bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                    if(err){
                        res.status(500).send({message: 'Error al encriptar la contraseña'})
                    }else if(passwordHash){
                        user.password = passwordHash;
                        user.save((err, saveUser)=>{
                            if(err){
                                res.status(500).send({message: 'ERROR  en el servidor'});
                            }else if(saveUser){
                                res.status(200).send({message: 'El usuario ' + params.username + ' se a guardado con exito', user: saveUser});
                            }else{
                                res.status(418).send({message: 'Error al guardar los datos'})
                            }
                        });

                    }else{
                        res.status(418).send({message: 'Error inesperado'});
                    }
                });
            }
        });
    }else{
        res.status(404).send({message: 'Ingrese los datos solicitados'});
    }
}


function updateUser (req, res){
    let userId = req.params.id;
    let update = req.body;

    User.findByIdAndUpdate(userId, update, {new:true}, (err, userUpdate)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(userUpdate){
            res.send({user: userUpdate});
        }else{
            res.status(404).send({message: 'No se han actualizado los datos'});
        }
    });
};


function deleteUser (req, res){
    var userId = req.params.id;

    User.findByIdAndDelete(userId, (err, userDelete)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(userDelete){
            res.send({message:'El usuario a sido eliminado'});
        }else{
            res.status(404).send({message: 'No se ha eliminado el usuario de la Base de Datos'});
        }
    });
};


function listUsers(req, res){
    User.find({}, (err, listU)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(listU){
            res.send({Usuarios: listU});
        }else{
            res.status(404).send({message: 'No existen datos en la Base de Datos'});
        }
    })
};


//BUSCAR RANGO DE FECHAS
function disponibilidadHotel(req, res){
    var params = req.body;

    Hotel.find({fechaDeAtencionI:{$lte:new Date(params.fechaDeAtencionI)},fechaDeAtencionF: {$gte:new Date(params.fechaDeAtencionF)}}, (err, find)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(find){
            res.send({message: find});
        }else{
            res.status(404).send({message: 'No se encontro ninguna hotel disponible para estas fechas'})
        }
    })
};

//BUSCAR POR CALIFICACION
function searchStars(req, res){

    var find = Hotel.find({}).sort('starts');
 
    find.exec((err, hotelSearch) => {
        if (err) {
            res.status(500).send({ message: 'Error en la petición.' });
        } else if (!hotelSearch) {
            res.status(404).send({ message: 'No hay calificaciones registradas' });
        } else {
            res.send({ hotel: hotelSearch });
        }
    });
}

//BUSCAR POR ORDEN ALFABETICO
function searchOrdenAlfabetico(req, res) {
    var find = Hotel.find({}).sort('name');
    find.exec((err, searchStars)=>{
        if(err){
            res.status(500).send({ message: 'Error en el servidor' });
        }else if(!searchStars){
            res.status(404).send({ message: 'No hay datos de empresas registradas'});
        }else{
            res.send({hotel:searchStars});
        }
    });
};
//BUSCAR POR ZA
function searchMenorMayor(req, res) {
    var find = Hotel.find({}).sort({price:1});
    find.exec((err, searchStars)=>{
        if(err){
            res.status(500).send({ message: 'Error en el servidor' });
        }else if(!searchStars){
            res.status(404).send({ message: 'No hay datos de Stars'});
        }else{
            res.send({hotel:searchStars});
        }
    });
};

//BUSCAR POR AZ
function searchMayorMenor(req, res) {
    var find = Hotel.find({}).sort({price: -1});
    find.exec((err, searchStars)=>{
        if(err){
            res.status(500).send({ message: 'Error en el servidor' });
        }else if(!searchStars){
            res.status(404).send({ message: 'No hay datos de Stars'});
        }else{
            res.send({hotel:searchStars});
        }
    });
};


module.exports = {
    loginUser,
    saveUser,
    updateUser,
    deleteUser,
    listUsers,
    searchStars,
    searchOrdenAlfabetico,
    searchMenorMayor,
    searchMayorMenor,
    disponibilidadHotel,
}