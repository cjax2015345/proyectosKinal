'use strict'

var jwt = require('jwt-simple');
var moment = require('moment');
var key = '123';
var key2 = '456';

exports.ensureAuthenticatedHotel = (req, res, next)=>{
    if(!req.headers.authorization){
        res.status(403).send({message: 'Ingrese un token, Sin autenticación'});
    }else{
        var token = req.headers.authorization.replace(/['"]+/g, '');
        try{
            var payload = jwt.decode(token, key2);
            if(payload.exp <= moment().unix()){
                res.status(401).send({message: 'Token a expirado'});
            }else if(payload.role != 'HOTEL'){
                res.status(401).send({message: 'Necesita permisos de HOTEL para ingresar a esta ruta'});
            }
        }catch(ex){
            return res.status(404).send({message: 'Token no valido'})
        }
        req.hotel = payload;
        next();
    };
};

exports.ensureAuthenticatedAdmin = (req, res, next)=>{
    if(!req.headers.authorization){
        res.status(403).send({message: 'Ingrese un token, Sin autenticación'});
    }else{
        var token = req.headers.authorization.replace(/['"]+/g, '');
        try{
            var payload = jwt.decode(token, key);
            if(payload.exp <= moment().unix()){
                res.status(401).send({message: 'Token a expirado'});
            }else if(payload.role != 'ADMIN'){
                res.status(401).send({message: 'Necesita permisos de ADMIN para ingresar a esta ruta'});
            }
        }catch(ex){
            return res.status(404).send({message: 'Token no valido'})
        }
        req.user = payload;
        next();
    };
};

exports.ensureAuthenticated = (req, res, next)=>{
    if(!req.headers.authorization){
        res.status(403).send({message: 'Ingrese un token, Sin autenticación'});
    }else{
        var token = req.headers.authorization.replace(/['"]+/g, '');
        try{
            var payload = jwt.decode(token, key);
            if(payload.exp <= moment().unix()){
                res.status(401).send({message: 'Token a expirado'});
            }else if(payload.role != 'ADMIN'){
                if(payload.role != 'USER'){
                res.status(401).send({message: 'Necesita permisos de USER para ingresar a esta ruta'});
                }
            }
        }catch(ex){
            return res.status(404).send({message: 'Token no valido'})
        }
        req.user = payload;
        next();
    };
};

