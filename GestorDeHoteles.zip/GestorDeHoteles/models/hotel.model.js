'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hotelSchema = Schema({
    name: String,
    phone: Number,
    stars: Number,
    price: Number,
    role: String,
    hotelNumber: Number,
    password: String,
    fechaDeAtencionI: Date,
    fechaDeAtencionF: Date,
});

module.exports = mongoose.model('hotel', hotelSchema);
