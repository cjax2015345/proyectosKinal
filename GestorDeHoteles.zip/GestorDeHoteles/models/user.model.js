'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = Schema({
    name: String,
    lastname: String,
    username: String,
    email: String,
    phone: Number,
    role: String,
    password: String,
});

module.exports = mongoose.model('user', userSchema);