'use strict'

var express = require('express');
var controllerHotel = require('../controllers/hotel.controller');
var api = express.Router();
var mdAuth = require('../middlewares/authenticated')

api.post('/hotelLogin', controllerHotel.hotelLogin);
api.post('/saveHotel', mdAuth.ensureAuthenticatedAdmin, controllerHotel.saveHotel);
api.put('/updateHotel/:id', mdAuth.ensureAuthenticatedHotel, controllerHotel.updateHotel);
api.delete('/deleteHotel/:id', mdAuth.ensureAuthenticatedHotel, controllerHotel.deleteHotel);
api.get('/listHotel', mdAuth.ensureAuthenticated, controllerHotel.listHotel);

module.exports = api;