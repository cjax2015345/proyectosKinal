'use strict'

var express = require('express');
var controllerUser = require('../controllers/user.controller');
var mdAuth = require('../middlewares/authenticated');
var api = express.Router();

api.post('/loginUser', controllerUser.loginUser);
api.post('/saveUser', controllerUser.saveUser);
api.put('/updateUser/:id', mdAuth.ensureAuthenticated, controllerUser.updateUser);
api.delete('/deleteUser/:id', mdAuth.ensureAuthenticated, controllerUser.deleteUser);
api.get('/listUser', mdAuth.ensureAuthenticatedAdmin, controllerUser.listUsers);
//RUTAS DE BUSCAR
api.get('/searchStars', mdAuth.ensureAuthenticated, controllerUser.searchStars);
api.get('/searchOrdenAlfabetico', mdAuth.ensureAuthenticated, controllerUser.searchOrdenAlfabetico);
api.get('/searchMenorMayor', mdAuth.ensureAuthenticated, controllerUser.searchMenorMayor);
api.get('/searchMayorMenor', mdAuth.ensureAuthenticated, controllerUser.searchMayorMenor);
api.post('/disponibilidadHotel', mdAuth.ensureAuthenticated, controllerUser.disponibilidadHotel);

module.exports = api;


