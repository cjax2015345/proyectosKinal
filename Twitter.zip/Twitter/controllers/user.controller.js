'use strict'

var User = require("../models/user.model");
var Tweet = require("../models/tweet.model");
var bcrypt = require("bcrypt-nodejs");
var jwt = require("../services/jwt");

function commands(req, res) {
  var params = req.body;
  var command = req.body.command;
  var space = command.split(" ");

  //LOGIN=================================================================================================================
  //----------------------------------------------------------------------------------------------------------
  if (space[0] == "login") {
    var username = space[1];
    var password = space[2];
    if (username != null) {
      User.findOne({$or: [{ username: username }, { email: email }],},(err, check) => {
          if (err) {
            res.status(500).send({ message: "Error general" });
          }else if (check) {
              bcrypt.compare(password, check.password, (err, passworOk) => {
                  if (err) {
                      res.status(500).send({message: "Error en comparar",});
                    }else if (passworOk) {
                      if ((params.gettoken = true)) {
                        res.send({token: jwt.createToken(check),});
                }else {
                  res.send({message: "Bienvenido!.", user: check,});
                }
              }else {
                res.send({message: "Contraseña incorrecta.",});
              }
            });
          }else {
            res.send({ message: "Usuario Incorrecto."});
          }
        });
      }else {
        res.send({ message: "Ingrese todos los datos." });
      }
    }
    
  //CREAR REGISTER ============================================================================================================
  //----------------------------------------------------------------------------------------------------------------
  if (space[0] == "register") {
    var user = new User();
    var name = space[1];
    var username = space[2];
    var email = space[3];
    var password = space[4];
    if (name != null && email != null && username != null && password !=null) {
      User.findOne({$or: [{ name: name }, { email: email }, { username: username }],},(err, saveOk) => {
        if (err) {
          res.status(500).send({ message: "Error inesperado.", err });
        }else if (saveOk) {
          res.status(200).send({ message: "Usuario o correo ya esta en uso.", err });
        }else {
          user.name = name;
          user.username = username;
          user.email = email;
          user.password = password;
          bcrypt.hash(password, null, null, (err, passwordHash) => {
            if (err) {
              res.status(500).send({ message: "Error al encriptar Contraseña" });
            }else if (passwordHash) {
              user.password = passwordHash;
              user.save((err, userSave) => {
                if (err) {
                  res.status(500).send({ message: "Error general al guardar cambios" });
                }else if (userSave) {
                  res.status(200).send({ message: "Usuario Creado", user: userSave });
                }else {
                  res.status(404).send({ message: "Usuario no guardado" });
                }
              });
            }else {
              res.status(418).send({ message: "Error Inesperado" });
            }
          });
        }
      });
    } else {
      res.send({ message: res });
    }
  }

  //VER PERFIL===================================================================================================================
  //-------------------------------------------------------------------------------------------------------------------
  if (space[0] == "profile") {
    var username = space[1];
    User.find({$or: [{ username: { $regex: "^" + space[1], $options: "i" }}],}, (err, userF) => {
      if (err) {
        res.status(404).send({ message: "Error general.", err });
      } else if (userF) {
        res.send({ profile: "Perfil:", userF });
      } else {
        res.send({ message: "Ingrese nombre del usuario." });
      }
    }
    );
  }

  //SEGUIR======================================================================================================================
  //-------------------------------------------------------------------------------------------------------------
  if (space[0] == "follow") {
    var username = space[1];
    if (space.length == 2) {
      User.findOne({ username: username }, (err, findUser) => {
        if (err) {
          res.status(500).send({ message: "Error " + err });
        }else if (findUser) {
          if (req.user.username != findUser.username) {
            User.findOne({ _id: req.user.sub, followers: findUser._id }, (err, userFind) => {
              if (err) {
                res.status(500).send({ message: "Error " + err });
              }else if (userFind) {
                res.status(200).send({ message: "Ya estas siguiendo a este usuario" });
                }else {
                  User.findByIdAndUpdate(req.user.sub,{ $push: { followers: findUser._id } },{ new: true }, (err, followedA) => {
                    if (err) {
                      res.status(500).send({ message: "Error " + err });
                    }else if (followedA) {
                      User.findByIdAndUpdate(findUser._id,{ $push: { followed: req.user.sub } },{ new: true },(err, sucessConect) => {
                        if (err) {
                          res.status(500).send({ message: "Error " + err });
                        } else if (sucessConect) {
                          res.send({ FOLLOW: findUser.username, sucessConect });
                        } else {
                          res.status(500).send({message: "Proceso no ejecutado.",});
                        }
                      }).populate("tweet");
                    }else {
                      res.status(500).send({message: "Proceso no ejecutado.",});
                    }
                  }
                  );
                }
              }
              );
            }else {
              res.status(200).send({ message: "No te puedes seguir a ti" });
            }
          }else {
            res.status(404).send({ message: "Sin coincidencias." });
          }
        });
      }else {
        res.send({ message: "No se han ingresado los parametros necesarios." });
      }
  }

  //DEJAR DE SEGUIR================================================================================================
  //------------------------------------------------------------------------------------------------------
  if (space[0] == "unfollow") {
    var username = space[1];
    if (space.length == 2) {
      User.findOne({ username: username }, (err, findUser) => {
        if (err) {
          res.status(500).send({ message: "Error " + err });
        }else if (findUser) {
          if (req.user.username != findUser.username) {
            User.findOne({ _id: req.user.sub, followers: findUser._id },(err, userFind) => {
              if (err) {
                res.status(500).send({ message: "Error " + err });
              }else if (userFind) {
                User.findByIdAndUpdate(req.user.sub,{ $pull: { followers: findUser._id } },{ new: true }, (err, unfollowed) => {
                  if (err) {
                    res.status(500).send({ message: "Error " + err });
                  }else if (unfollowed) {
                    User.findByIdAndUpdate(findUser._id,{ $pull: { followed: req.user.sub }},{ new: true }, (err, sucessConect) => {
                      if (err) {
                        res.status(500).send({ message: "Error " + err });
                      }else if (sucessConect) {
                        res.send({ UNFOLLOW: findUser.username, sucessConect });
                      }else {
                        res.status(500).send({message: "No se pudo ejecutar el proceso.",});
                      }
                    });
                  }else {
                    res.status(500).send({message: "No se pudo ejecutar el proceso.",})
                  }});
                }else {
                  res.status(200).send({message:"Aun no estas siguiendo a este usuario.",});
                }
              });
            } else {
              res.status(200).send({ message: "No te puedes seguir a ti" });
            }
          } else {
            res.status(404).send({ message: "Sin coincidencias" });
          }
        });
      } else {
        res.send({ message: "No se han ingresado los parametros necesarios." });
      }
    }

  //AGREGAR TWEET==================================================================================================
  //--------------------------------------------------------------------------------------------------
  if (space[0] == "add_tweet") {
    var idU = req.user.sub;
    var tweet = new Tweet();
    if (space[1] != null) {
      tweet.author = idU;
      var cadena = "";
      for (var i in space) {
        if (i >= 1) {
          var texto = space[i];
          cadena = cadena + " " + texto;
          i++;
        }
      }
      tweet.description = cadena;
      tweet.save((err, post) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        }else if (post) {
          User.findByIdAndUpdate(idU,{ $push: { tweet: post._id } },{ new: true }, (err, userPost) => {
            if (err) {
              res.status(404).send({ message: "Error general.", err });
            }else if (userPost) {
              res.send({message: "Tweet publicado.",userPost,});
            } else {
              res.send({ message: "Error inesperado.", err });
            }
          }).populate("tweet");
        }else {
          res.send({ message: "Error inesperado.", err });
        }});
      }else {
        res.send({message: "Por favor, escribir dentro del tweet.",
      });
    }
  }

  //ELIMINAR UN TWEET=======================================================================================================
  //----------------------------------------------------------------------------------------
  if (space[0] == "delete_tweet") {
    var idT = space[1];
    var idU = req.user.sub;
    if (idT != null) {
      Tweet.findById(idT, (err, Found) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        }else if (Found) {
          if (Found.author == idU) {
            User.findOneAndUpdate({ _id: idU, tweet: idT },{ $pull: { tweet: idT } },{ new: true },(err, deleteT) => {
              if (err) {
                res.status(404).send({ message: "Error general.", err });
              }else if (deleteT) {
                Tweet.findByIdAndRemove(idT, (err, tweetRemoved) => {
                  if (err) {
                    res.status(404).send({ message: "Error de servidor.", err });
                  }else if (tweetRemoved) {
                    res.send({ TweetRemoved: deleteT });
                  }else {
                    res.status(418).send({message: "No se ha eliminado el tweet",err,});
                  }
                });
              }else {
                res.send({ message: "Error inesperado.", err });
              }
            });
          }else {
            res.send({message: "Sin permiso para esta accion.",});
          }
        }else {
          res.status(404).send({ message: "Sin coincidencias." });
        }
      });
    } else {
      res.send({ message: "Por favor, colocar el ID para eliminarlo",});
    }
  }

  //EDITAR TWEET=======================================================================================================
  //------------------------------------------------------------------------------------------------------
  if (space[0] == "edit_tweet") {
    var idU = req.user.sub;
    var idT = space[1];
    var description = space[2];
    if (idT != null && description != null) {
      Tweet.findById(idT, (err, tweetFound) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        } else if (tweetFound) {
          if (tweetFound.author == idU){
            var cadena = "";
            for (var i in space) {
              if (i >= 2) {
                var descripcion = space[i];
                cadena = cadena + " " + descripcion;
                i++;
              }
            }
            tweetFound.description = cadena;
            Tweet.findByIdAndUpdate(idT,{ description: cadena },{ new: true },(err, updateT) => {
              if (err) {
                res.status(404).send({ message: "Error general.", err });
              }else if (updateT) {
                res.send({ UPDATE: "El Tweet a sido actualizado.", updateT });
              }else {
                res.send({ message: "Error inesperado." });
              }
            }).populate("tweet");
          }else {
            res.send({message: "No tienes permiso.",
          });
        }
      }else {
        res.status(404).send({ message: "Sin coincidencias." });
      }});
    }else {
      res.status(418).send({ message: "Por favor, llenar todos los parametros." });
    }
  }

  //VER TWEETS===========================================================================================================================
  //----------------------------------------------------------------------------------------------------------------------------
  if (space[0] == "view_tweets") {
    var username = space[1];
    User.find({$or: [{ username: { $regex: "^" + space[1], $options: "i" } }],},(err, userF) => {
      if (err) {
        res.status(404).send({ message: "Error general.", err });
      }else if (userF) {
        res.send({ tweets: "Perfil:", userF });
      }else {
        res.send({ message: "Ingrese el nombre del usuario." });
      }
    }).populate("tweet");
  }
}

module.exports = {
  commands,
};