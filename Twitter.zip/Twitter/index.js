'use strict'

var mongoose = require('mongoose');
var port = 3800;
var app = require('./app');

mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost:27017/TWITTERDB', {useNewUrlParser:true, useUnifiedTopology:true, useFindAndModify:false})
    .then(()=>{
        console.log('Conexion exitosa a la base de datos');
        app.listen(port, ()=>{
            console.log('Servidor corriendo en el puerto', port);
            console.log('-------------------------------------------------------------------------');
            console.log('Funciones explicadas para el proyecto:');
            console.log('Comandos funcionan por espacios sin comas (commands)');
            console.log('register: commands, name, username, email, password');
            console.log('login: commands, username y password');
            console.log('profile y ver tweets: commands, busqueda en general o con la inicial de una palabra');
            console.log('follow y unfollow: commands e ingresar nombre de usuario');
            console.log('add_tweet: commands y escribir un post');
            console.log('edit_tweet: commands, colocar id del tweet y escribir un post');
            console.log('delete_tweet: commands y colocar id del tweet');
            

        });
    }).catch(err =>{
        console.log('Error al conectarse con la base de datos', err);
    });