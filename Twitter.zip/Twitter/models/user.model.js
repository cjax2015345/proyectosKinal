'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = Schema({
    name: String,
    username: String,
    password: String,
    email: String,
    address: String,
    followers: [{ type: Schema.Types.ObjectId, ref: 'user'}],
    followed: [{ type: Schema.Types.ObjectId, ref: 'user'}],
    tweet: [{ type: Schema.Types.ObjectId, ref: 'tweet'}]
   
});

module.exports = mongoose.model('user', userSchema);

