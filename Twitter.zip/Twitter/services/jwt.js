"use strict";

var jwt = require("jwt-simple");
var moment = require("moment");
var key = "123456";

exports.createToken = (user) => {
  var payload = {
    sub: user._id,
    name: user.name,
    username: user.username,
    password: user.password,
    email: user.email,
    address: user.address,
    followers: user.followers,
    followed: user.followed,
    iat: moment().unix(),
    exp: moment().add(5, "hours").unix(),
  };
  return jwt.encode(payload, key);
};
